import numpy as np 
import matplotlib.pyplot as plt
from scipy.io import wavfile
import math


samplerate, data = wavfile.read('test.wav')
####  Plot data in time-domain ####
times = np.arange(len(data))/float(samplerate)
plt.plot(times, data)
###################################
plt.title('Sound amplitude in time domain')
plt.xlabel('times (s)')
plt.ylabel('amplitude')
plt.show()

