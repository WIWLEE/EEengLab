import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
from scipy import fftpack
from scipy.io import wavfile


samplerate, data = wavfile.read('test.wav')
#### Determine the fftsize using data ####
times = np.arange(len(data))/float(samplerate)
fftsize = (len(times)); # 분석의 대상이 되는 Time domain data의 length
##########################################

mat_file = sio.loadmat('filter.mat')
LPF_coefficients_500 = mat_file['LPF_coefficients_500']
HPF_coefficients_500 = mat_file['HPF_coefficients_500']

h1_500 = np.reshape(LPF_coefficients_500, LPF_coefficients_500.shape[0])
h2_500 = np.reshape(HPF_coefficients_500, HPF_coefficients_500.shape[0])

fft_LPF_500 = fftpack.fft(h1_500, fftsize)
fft_HPF_500 = fftpack.fft(h2_500, fftsize)
data_freq = fftpack.fftfreq(fftsize, 1/float(samplerate))

data_freq = fftpack.fftshift(data_freq)
fft_LPF_500 = fftpack.fftshift(fft_LPF_500)
fft_HPF_500 = fftpack.fftshift(fft_HPF_500)

plt.figure(1)
plt.plot(data_freq, abs(fft_LPF_500))
plt.title('LPF')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')

plt.figure(2)
plt.plot(data_freq, abs(fft_HPF_500))
plt.title('HPF')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')
plt.show()


