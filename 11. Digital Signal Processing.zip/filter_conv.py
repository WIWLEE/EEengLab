# Import the required libraires
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
from scipy import fftpack
from scipy.io import wavfile
import os

# Read "test.wav"
samplerate, data = wavfile.read('test.wav')
times = np.arange(len(data))/float(samplerate)
total_slot = times.shape[0]

# Load 'filter.mat' and save the coefficients
mat_file = sio.loadmat('filter.mat')
LPF_coefficients_500 = mat_file['LPF_coefficients_500']
HPF_coefficients_500 = mat_file['HPF_coefficients_500']

# Reshape the LPF/HPF coefficients
h1_500 = np.reshape(LPF_coefficients_500, LPF_coefficients_500.shape[0])
h2_500 = np.reshape(HPF_coefficients_500, HPF_coefficients_500.shape[0])

# Apply convolution for filtering
LPF_coefficients_500 = np.concatenate(LPF_coefficients_500).tolist() #1차원 배열로 변경
HPF_coefficients_500 = np.concatenate(HPF_coefficients_500).tolist() #1차원 배열로 변경
data_LPF = np.convolve(data, LPF_coefficients_500, 'same') #convolution
data_HPF = np.convolve(data, HPF_coefficients_500, 'same') #convolution

# Plot the filtered signals in time-domain
plt.figure(1)
plt.plot(times, data_LPF)
plt.title('Sound passing LPF in time domain')
plt.xlabel('times (s)')
plt.ylabel('amplitude')

plt.figure(2)
plt.plot(times, data_HPF)
plt.title('Sound passing HPF in time domain')
plt.xlabel('times (s)')
plt.ylabel('amplitude')
plt.show()


# Save the filtered signals
wav_lpf = 'conv_test_LPF_freq.wav'
sio.wavfile.write(wav_lpf, samplerate, data_LPF.astype(np.int16))
wav_hpf = 'conv_test_HPF_freq.wav'
sio.wavfile.write(wav_hpf, samplerate, data_HPF.astype(np.int16))

(lpf_dir, lpf_id) = os.path.split(wav_lpf)
print("path : ", lpf_dir) # 경로 지정 없을 시 같은 폴더에 저장 밑 출력 없음
print("name : ", lpf_id)
(hpf_dir, hpf_id) = os.path.split(wav_hpf)
print("path : ", hpf_dir) # 경로 지정 없을 시 같은 폴더에 저장 밑 출력 없음
print("name : ", hpf_id)
