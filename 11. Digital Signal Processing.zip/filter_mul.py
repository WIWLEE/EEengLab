import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
from scipy import fftpack
from scipy.io import wavfile
import os

samplerate, data = wavfile.read('test.wav')
times = np.arange(len(data))/float(samplerate)
total_slot = times.shape[0]

mat_file = sio.loadmat('filter.mat')
LPF_coefficients_500 = mat_file['LPF_coefficients_500']
HPF_coefficients_500 = mat_file['HPF_coefficients_500']

h1_500 = np.reshape(LPF_coefficients_500, LPF_coefficients_500.shape[0])
h2_500 = np.reshape(HPF_coefficients_500, HPF_coefficients_500.shape[0])

fftsize = total_slot+h1_500.shape[0]-1 #zero padding

data_fft = fftpack.fft(data, fftsize)
data_freq = fftpack.fftfreq(fftsize, 1/float(samplerate))
###########################################
fft_LPF_500 = fftpack.fft(h1_500, fftsize) # h1_500이라는 LPF system h1(Impurse response)를 FFT를 이용해 frequency domain H1 (fft_LPF_500)으로 변환함
fft_HPF_500 = fftpack.fft(h2_500, fftsize) # h2_500이라는 HPF system h2(Impurse response)를 FFT를 이용해 frequency domain H2 (fft_HPF_500)으로 변환함

data_LPF_freq = data_fft*fft_LPF_500 # 원본 data FFT와 LPF system FFT의 곱이 이루어진 frequency domain data를 얻음 (Y = H*X)
data_HPF_freq = data_fft*fft_HPF_500 # 원본 data FFt와 HPF system FFT의 곱이 이루어진 frequency domain data를 얻음 (Y = H*X)

data_LPF = fftpack.ifft(data_LPF_freq) # 위의 data_LPF_freq를 inverse FFT를 통해 LPF가 적용된 time domain data를 얻음
data_HPF = fftpack.ifft(data_HPF_freq) # 위의 data_HPF_freq를 inverse FFT를 통해 HPF가 적용된 time domain data를 얻음
###########################################

plt.figure(1)
plt.plot(data_freq, abs(data_LPF_freq))
plt.title('Sound passing LPF in frequency domain')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')

plt.figure(2)
plt.plot(data_freq, abs(data_HPF_freq))
plt.title('Sound passing HPF in frequency domain')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')
plt.show()

wav_lpf = 'test_LPF_freq.wav'
sio.wavfile.write(wav_lpf, samplerate, data_LPF.astype(np.int16))
wav_hpf = 'test_HPF_freq.wav'
sio.wavfile.write(wav_hpf, samplerate, data_HPF.astype(np.int16))

(lpf_dir, lpf_id) = os.path.split(wav_lpf)
print("path : ", lpf_dir) # 경로 지정 없을 시 같은 폴더에 저장 밑 출력 없음
print("name : ", lpf_id)
(hpf_dir, hpf_id) = os.path.split(wav_hpf)
print("path : ", hpf_dir) # 경로 지정 없을 시 같은 폴더에 저장 밑 출력 없음
print("name : ", hpf_id)





