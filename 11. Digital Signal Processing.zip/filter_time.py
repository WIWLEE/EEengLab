import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio


mat_file = sio.loadmat('filter.mat')
# filter.mat 에는 'LPF_coefficients_500'과 'HPF_coefficients_500'이 각각 길이 1001 x 1 벡터로 저장되어 있음
LPF_coefficients_500 = mat_file['LPF_coefficients_500']
HPF_coefficients_500 = mat_file['HPF_coefficients_500']

h1_500 = np.reshape(LPF_coefficients_500, LPF_coefficients_500.shape[0]) # (1001 x 1) 2차원 행렬을 길이 1001짜리 1차원 벡터로 reshape
h2_500 = np.reshape(HPF_coefficients_500, HPF_coefficients_500.shape[0]) # (1001 x 1) 2차원 행렬을 길이 1001짜리 1차원 벡터로 reshape

plt.figure(1)
plt.plot(np.arange(len(h1_500)), h1_500)
plt.title('LPF')
plt.xlabel('index')
plt.ylabel('amplitude')

plt.figure(2)
plt.plot(np.arange(len(h2_500)), h2_500)
plt.title('HPF')
plt.xlabel('index')
plt.ylabel('amplitude')
plt.show()




