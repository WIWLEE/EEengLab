import numpy as np
import scipy.io as sio
import scipy.io.wavfile
from scipy import fftpack
import matplotlib.pyplot as plt
import math
import time

start=time.time()
samplerate, data = sio.wavfile.read('labC3_32.wav')
fftsize=len(data)
data_fft = fftpack.fft(data, fftsize)
end=time.time()
print(f"{end-start:.5f} sec")
power=(np.abs(data_fft))**2
samplefreq=fftpack.fftfreq(fftsize,1/samplerate)
plt.plot(samplefreq,power)
plt.xlabel('Frequency[Hz]')
plt.ylabel('power')
plt.show()
