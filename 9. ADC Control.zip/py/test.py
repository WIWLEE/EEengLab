import numpy as np
import scipy.io as sio
import scipy.io.wavfile
import matplotlib.pyplot as plt
samplerate, data=sio.wavfile.read('week9.wav')
times=np.arange(len(data))/float(samplerate)
plt.fill_between(times,data)
plt.xlim(times[0],times[-1])
plt.xlabel('times (s)')
plt.ylabel('amplitude')
plt.show()
