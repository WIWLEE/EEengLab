import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy import fftpack

samplerate, data = wavfile.read('test.wav')
times = np.arange(len(data))/float(samplerate)
fftsize = times.shape[0]

f_th = 100
len_h = 2001
n = np.linspace(-(len_h-1)/2, (len_h-1)/2, len_h)
HPF_made = -2*f_th / float(samplerate) * np.sinc(2*f_th /float(samplerate) * n)
HPF_made[np.int16((len_h+1)/2)] += 1


plt.figure(1)
plt.plot(n/float(samplerate), HPF_made)
plt.title('HPF')
plt.xlabel('times[s]')
plt.ylabel('amplitude')

fft_HPF_made = fftpack.fft(HPF_made, fftsize)
data_freq = fftpack.fftfreq(fftsize, 1/float(samplerate))


fft_HPF_made = fftpack.fftshift(fft_HPF_made)
data_freq = fftpack.fftshift(data_freq)

plt.figure(2)
plt.plot(data_freq, abs(fft_HPF_made))
plt.title('HPF')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')
plt.show()
