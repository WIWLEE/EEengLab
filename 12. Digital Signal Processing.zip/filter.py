import numpy as np
import scipy.io as sio
import matplotlib.pyplot as plt
from scipy.io import wavfile
import os
from scipy import fftpack

samplerate, data = wavfile.read('domisol.wav')

f_th = 300
len_h = 2001
n = np.linspace(-(len_h-1)/2, (len_h-1)/2, len_h)
LPF_made = 2*f_th/float(samplerate)*np.sinc(2*f_th/float(samplerate)*n)


f_th = 300
len_h = 2001
n = np.linspace(-(len_h-1)/2, (len_h-1)/2, len_h)
HPF_made = -2*f_th / float(samplerate) * np.sinc(2*f_th /float(samplerate) * n)
HPF_made[np.int16((len_h+1)/2)] += 1


data_LPF = np.convolve(data, LPF_made)
times_LPF = np.arange(len(data_LPF))/float(samplerate)

plt.figure(1)
plt.fill_between(times_LPF, data_LPF)
plt.xlim(times_LPF[0], times_LPF[-1])
plt.title('Sound passing LPF in time domain')
plt.xlabel('times(s)')
plt.ylabel('amplitude')



data_HPF = np.convolve(data, HPF_made)
times_HPF = np.arange(len(data_HPF))/float(samplerate)

plt.figure(2)
plt.fill_between(times_HPF, data_HPF)
plt.xlim(times_HPF[0], times_HPF[-1])
plt.title('Sound passing HPF in time domain')
plt.xlabel('times(s)')
plt.ylabel('amplitude')
plt.show()

wav_lpf = 'test_LPF_2001.wav'
sio.wavfile.write(wav_lpf,samplerate,data_LPF.astype(np.int16))

(lpf_dir, lpf_id) = os.path.split(wav_lpf)
print("path: ", lpf_dir)
print("name: ", lpf_id)

wav_hpf = 'test_HPF_2001.wav'
sio.wavfile.write(wav_hpf,samplerate,data_HPF.astype(np.int16))

(hpf_dir, hpf_id) = os.path.split(wav_hpf)
print("path: ", hpf_dir)
print("name: ", hpf_id)

##fft##
samplerate, data = wavfile.read('test_LPF_2001.wav')
times = np.arange(len(data))/float(samplerate)
fftsize = (len(times))
data_fft = fftpack.fft(data, fftsize)
data_freq = fftpack.fftfreq(fftsize, 1/float(samplerate))
data_fft = fftpack.fftshift(data_fft)
data_freq = fftpack.fftshift(data_freq)

plt.figure(3)
plt.plot(data_freq, abs(data_fft))
plt.xlim(-1000,1000)
plt.title('LPF')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')
plt.show()
####

samplerate, data = wavfile.read('test_HPF_2001.wav')
times = np.arange(len(data))/float(samplerate)
fftsize = (len(times))
data_fft = fftpack.fft(data, fftsize)
data_freq = fftpack.fftfreq(fftsize, 1/float(samplerate))
data_fft = fftpack.fftshift(data_fft)
data_freq = fftpack.fftshift(data_freq)

plt.figure(4)
plt.plot(data_freq, abs(data_fft))
plt.xlim(-1000,1000)
plt.title('HPF')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')
plt.show()
####