import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy import fftpack

samplerate, data = wavfile.read('test.wav')
times = np.arange(len(data))/float(samplerate)
fftsize = times.shape[0]

f_th = 200
len_h = 10001
#### Design LPF_made ####
n = np.linspace(-(len_h-1)/2, (len_h-1)/2, len_h)
LPF_made = 2*f_th / float(samplerate) * np.sinc(2*f_th /float(samplerate) * n)
#########################


plt.figure(1)
plt.plot(n/float(samplerate), LPF_made)
plt.title('LPF')
plt.xlabel('times[s]')
plt.ylabel('amplitude')

fft_LPF_made = fftpack.fft(LPF_made, fftsize)
data_freq = fftpack.fftfreq(fftsize, 1/float(samplerate))


fft_LPF_made = fftpack.fftshift(fft_LPF_made)
data_freq = fftpack.fftshift(data_freq)

plt.figure(2)
plt.plot(data_freq, abs(fft_LPF_made))
plt.title('LPF')
plt.xlabel('frequency [Hz]')
plt.ylabel('amplitude')
plt.show()